﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using _1124UseWCFService.ServiceReference1;

namespace _1124UseWCFService
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HelloWorldClient hc = new HelloWorldClient();
            textBox1.Text = hc.SayHello();
        }
    }
}
