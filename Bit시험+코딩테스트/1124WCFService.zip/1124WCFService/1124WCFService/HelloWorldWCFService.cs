﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1124WCFService
{
    //서비스 객체 : 반드시 계약 인터페이스를 상속 받아야 한다.
    class HelloWorldWCFService : IHelloWorld
    {
        public void foo()
        {
            throw new NotImplementedException();
        }

        public string SayHello()
        {
            return "Hello WCF World!";
        }
    }
}
