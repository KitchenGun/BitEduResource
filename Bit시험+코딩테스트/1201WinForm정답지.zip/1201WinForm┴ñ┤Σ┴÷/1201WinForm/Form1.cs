﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1201WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        #region 1. 전체출력[Form이 로드될 때]
        private void Form1_Load(object sender, EventArgs e)
        {
            PrintStudent();
        }

        private void PrintStudent()
        {
            List<Student> stulist = StuManager.Singleton.PrintAll();

            //리스트뷰 초기화
            listView1.Items.Clear();

            //라벨에 개수 출력
            label1.Text = String.Format("총 학생수 : {0}명", stulist.Count);

            //리스트뷰 출력
            foreach (Student stu in stulist)
            {
                string[] strs = new string[] {
                    stu.Number.ToString(), stu.Name, stu.SType.ToString(), stu.Grade.ToString() };
                ListViewItem lvi = new ListViewItem(strs);
                listView1.Items.Add(lvi);
            }
        }
        #endregion

        #region 2. Insert(삽입)
        private void 회원정보입력AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //1. 모달로 Form 출력
            StudentAddForm sform = new StudentAddForm();
            if (sform.ShowDialog() == DialogResult.OK)
            {
                //2. 모달 종료시 함수를 이용하여 정보 획득
                Student stu = sform.GetStudentInfo();

                //3. 획득한 정보 전달
                if (StuManager.Singleton.InsertStudent(stu) == true)
                {
                    //4. 성공시 호출
                    PrintStudent();
                }
                else
                {
                    //5. 실패시 메시지박스 출력
                    MessageBox.Show("저장 실패");
                }
            }
        }

        #endregion

        #region 3. Select(검색)

        //리스트뷰 이벤트 핸들러
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //선택된 아이템
                ListViewItem lvi = listView1.SelectedItems[0];
                //선택된 아이템의 학번
                int number = int.Parse(lvi.SubItems[0].Text);
                PrintStudentInfo(number);
            }
            catch(Exception)
            {

            }
        }

        //검색 버튼 이벤트 핸들러
        private void button1_Click(object sender, EventArgs e)
        {
            int number = int.Parse(textBox1.Text);
            PrintStudentInfo(number);
        }

        private void PrintStudentInfo(int number)
        {
            //1.Student 획득
            Student stu = StuManager.Singleton.NumberToStudent(number);            
            if(stu == null)
            {
                //2. 실패시 오류메시지 출력
                MessageBox.Show("검색 실패");
            }

            //3. 성공시 컨트롤에 출력
            textBox1.Text = stu.Number.ToString();
            
            textBox2.Text = stu.Name;

            if (stu.SType == SubjectType.COMMIT)    comboBox1.SelectedIndex = 0;
            else if (stu.SType == SubjectType.IT)   comboBox1.SelectedIndex = 1;
            else if (stu.SType == SubjectType.GAME) comboBox1.SelectedIndex = 2;
            else if (stu.SType == SubjectType.ETC)  comboBox1.SelectedIndex = 3;

            comboBox2.SelectedIndex = (stu.Grade - 1);
        }



        #endregion

        #region 4. Delete(삭제)
        private void button2_Click(object sender, EventArgs e)
        {
            //1. 학번 획득
            int number = int.Parse(textBox1.Text);

            //2. 삭제 호출
            if(StuManager.Singleton.DeleteStudent(number) == true)
            {
                //3. 리스트뷰 갱신
                PrintStudent();

                //제시한 문제에는 없지만 정보 컨트롤 초기화
                textBox1.Text = textBox2.Text = "";
                comboBox1.SelectedIndex = comboBox2.SelectedIndex = -1;
            }
            else
            {
                //4. 메시지 박스 출력
                MessageBox.Show("삭제 에러");
            }
        }

        #endregion

        #region 5. Update(수정)

        //수정버튼 이벤트 핸들러
        private void button3_Click(object sender, EventArgs e)
        {
            //1. 학번 획득
            int number = int.Parse(textBox1.Text);

            //1.1 추가 정보 획득
            SubjectType stype = (SubjectType)(comboBox1.SelectedIndex + 1);
            int grade = comboBox2.SelectedIndex + 1;

            //2. 수정기능 함수 호출
            if (StuManager.Singleton.UpdateStudent(number, stype, grade) == true)
            {
                //3. 리스트뷰 갱신
                PrintStudent();
            }
            else
            {
                //4. 메시지 박스 출력
                MessageBox.Show("삭제 에러");
            }
        }

        #endregion

        #region 기타 : 도움말>>프로그램정보...
        private void 프로그램정보VToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("프로그램명 : WinForm실습\r\n개발자명 : ccm\r\n개발일자 : 2020/12/01");
        }
        #endregion

        #region 기타 : 파일>>프로그램종료
        private void 프로그램종료XToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
