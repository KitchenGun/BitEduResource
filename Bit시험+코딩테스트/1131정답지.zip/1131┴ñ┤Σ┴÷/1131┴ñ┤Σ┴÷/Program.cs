﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1131정답지
{
    class Program
    {
        static void Main(string[] args)
        {
            App.Singleton.Run();
        }
    }
}
