﻿namespace Hyun
{
    class Empty : System.Windows.FrameworkElement
    {

    }
}