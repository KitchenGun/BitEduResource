//-------------------------------------------------------
// RadialPanelOrientation.cs (c) 2006 by Charles Petzold
//-------------------------------------------------------
namespace Petzold.CircleTheButtons
{
    public enum RadialPanelOrientation
    {
        ByWidth,
        ByHeight
    }
}